package java_chobo.ch07.overriding;


public class Main {

	public static void main(String[] args) {
		
		
		Point p = new Point();
		System.out.println(p.getLocation());
		
		 Point3D p1 = new Point3D();
		 System.out.println(p1.getLocation());
		 Point4D p2 = new Point4D();
		 System.out.println(p2.getLocation());
	
		
	}
	
}
