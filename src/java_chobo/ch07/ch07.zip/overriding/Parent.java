package java_chobo.ch07.overriding;

public class Parent {
	int x = 10;
	

}
