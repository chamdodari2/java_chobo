package java_chobo.ch07.test;

public class Tank {
	Marine marin = new Marine();
	
	void changeMode() {
		
		//공격모드로 변환한다
	}

	
	
}
