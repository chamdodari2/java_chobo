package java_chobo.ch07.test;

public class Marine extends Unit {
	
	void stimPack() {
		//스팀팩을 사용한다
	}
	
	

}
