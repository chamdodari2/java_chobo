package java_chobo.ch07.test;

public class Dropship {
	
	Tank tank = new Tank();
	void unload() {
		 //선택된 대상을 내린다
	}
	
	
}
