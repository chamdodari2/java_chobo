package java_chobo.ch07;

public class Child3 extends Parent3 implements MyInterface, MyInterface2 {
	
		public void method1() {
			
		System.out.println("method1() in child3");   //오버라이딩
	}
	
}
