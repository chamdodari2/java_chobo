package java_chobo.ch07;

public class Parent3 {
public void method2() {
	System.out.println("method2() in parent3");
}
}
