package java_chobo.ch07;

public class Ex7_11 {

	public static void main(String[] args) {
		 Child3 c = new Child3();
		 c.method1();
		 c.method2();
		 MyInterface.staticMethod();
		 MyInterface2.staticMethod();

	}

}
