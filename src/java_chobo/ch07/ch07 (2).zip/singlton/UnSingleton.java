package java_chobo.ch07.singlton;

public class UnSingleton {

}
