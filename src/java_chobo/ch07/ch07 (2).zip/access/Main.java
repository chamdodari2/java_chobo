package java_chobo.ch07.access;

public class Main {

	public static void main(String[] args) {
		AccessParent ap = new AccessParent();
		

	}

}
