package java_chobo.ch07.access;

public class AccessParent {  
	//접근지정자 4개 지정
	private int a;
	int b;
	protected int c;
	public int d;

}
