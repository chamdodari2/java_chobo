package java_chobo.ch07.ab;

public class SubAbstractTest2 extends AbstractTest {

	@Override
	void prnTest2() {
		// TODO Auto-generated method stub

	}

}
