package java_chobo.ch07.ab;

public abstract class AbstractTest {

	public void prnTest() {
		System.out.println("AbstractTest");
	}
	abstract void prnTest2();  //이렇게 하면  바디는 없고 메소드 선언만 있는것
}
