package java_chobo.ch07.test;

public class Computer extends Product {

	Computer() {
		super(200);
		
	}
	public String toString() {
		return "Computer";
	}
}
