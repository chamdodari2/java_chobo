package java_chobo.ch07.test;

 class Marine extends Unit {
	
	 
	 
	@Override
	void move(int x, int y) {
	
		
	}

	void stimPack() {
		System.out.println("스팀팩을 사용한다");
	}
	
	public static void main(String[] args) {
		
	}

}
