package java_chobo.ch07.test;

public class Audio extends Product {

	Audio( ) {
		super(50);
	
	}
	public String toString() {
		return "Audio";
	}
}
