package java_chobo.ch07.test03;

public class Person {

	
	String name;
	int age;
	String juso;
	public Person(String name, int age, String juso) {
		this.name = name;
		this.age = age;
		this.juso = juso;
	}
	
	
	
}
