package java_chobo.ch07.test02;

public class Pear extends Frute {

	@Override
	void print() {
		System.out.println("나는 배이다.");
		
	}

}
