package java_chobo.ch07.test02;

 abstract class Frute {
	abstract void print();
	

}
