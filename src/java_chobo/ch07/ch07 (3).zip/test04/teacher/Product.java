package java_chobo.ch07.test04.teacher;

public class Product {
	int price; // 제품의 가격

	Product(int price) {
		this.price = price;
	}

}
