package java_chobo.ch07.test04.teacher;

public class Audio extends Product {
	Audio() {
		super(50);
	}

	public String toString() {
		return "Audio";
	}

}
