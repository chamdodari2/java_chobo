package java_chobo.ch07.test04.teacher;

public class Computer extends Product {
	Computer() {
		super(200);
	}

	public String toString() {
		return "Computer";
	}

}
