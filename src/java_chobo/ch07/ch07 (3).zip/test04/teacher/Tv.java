package java_chobo.ch07.test04.teacher;


public class Tv extends Product {
	Tv() {
		super(100);
	}

	public String toString() {
		return "Tv";
	}
}
