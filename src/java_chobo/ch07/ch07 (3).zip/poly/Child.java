package java_chobo.ch07.poly;

	class Child extends Parent {
	

		

	}
	
