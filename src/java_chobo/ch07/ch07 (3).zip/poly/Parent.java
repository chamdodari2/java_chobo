package java_chobo.ch07.poly;

public class Parent {
	int x = 100;

	void method() {
		System.out.println("Parent Method");
	}
}
