package java_chobo.ch07.test;

public class Tv extends Product {

	Tv() {
		super(100); // Product 타입의  (100)

	}

	public String toString() {
		return "Tv";
	}
}
