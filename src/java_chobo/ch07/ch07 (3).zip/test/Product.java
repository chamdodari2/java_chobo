package java_chobo.ch07.test;

public class Product {

	int price; //제품의 가격
	
	Product(int price) {  //매개변수  (외부에서 입력한 값 던져주기)
		this.price = price;
		
		
		
	}
}
