package java_chobo.ch07.test;

public class Tank extends Unit {
	// Marine marin = new Marine();

	@Override
	void move(int x, int y) {

	}

	void changeMode() {
		System.out.println("공격모드로 변환");

	}

}
