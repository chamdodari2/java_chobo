package java_chobo.ch07.test;

public class Testtest1 {

	public static void main(String[] args) {

		String a = "김밥";

		
		String b = a.substring(0,1);
		System.out.println(b);
	}

}
