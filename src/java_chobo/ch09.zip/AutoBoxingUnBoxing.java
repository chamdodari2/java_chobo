package java_chobo.ch09;

public class AutoBoxingUnBoxing {

	public static void main(String[] args) {
		Integer i = new Integer(10);
		int a = i; // auto??   unboxing;
		Integer i2 = 100; // autoboxing

	}

}
